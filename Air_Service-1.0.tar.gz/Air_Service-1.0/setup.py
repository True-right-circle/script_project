from distutils.core import setup

setup(name='Air_Service',
      version='1.0',
      py_modules=['internet','main','testtk']
      )
