from distutils.core import setup

setup(name='airline',
      version='1.0',
      py_modules=['internet','mail','tk','main'],
      )